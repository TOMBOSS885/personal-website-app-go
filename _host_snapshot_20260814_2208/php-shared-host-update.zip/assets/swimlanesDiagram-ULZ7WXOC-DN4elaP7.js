import{n as e}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";import"./src-Cz8bXOH0.js";import"./chunk-I66GZJ75-DdYaiX0f.js";import"./chunk-NSK5VX7P-D-0ABNS_.js";import"./chunk-4I5QYGJK-CbTUL6Lx.js";import"./chunk-WRU74C26-B-70hck8.js";import"./chunk-7BUUIJ7U-Bb538aSH.js";import"./chunk-UBXNYLIW-BAHXStnk.js";import"./chunk-2GRJ4B5K-BuJFzK6j.js";import"./chunk-XXDRQBXY-DlK_iNGL.js";import"./chunk-KBJHAD2P-BweeKxd9.js";import"./chunk-W5SLKNZC-CPb9RWfs.js";import"./chunk-QR6OTTB3-Dg4bJxDm.js";import"./chunk-7Z6QIM7H-Mh1DkXS3.js";import"./chunk-J7OUQ5F2-BbLuKSUZ.js";import"./chunk-ZIRB5QZD-C6fEPe3t.js";import{r as t,t as n}from"./chunk-JQJVKLGR-C7GpkA9z.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};